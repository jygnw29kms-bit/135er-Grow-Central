# Grow Light Meter iOS

Kamera-basierte Schätzung von Lux, PPFD und DLI für iPhone und iPad.

## Voraussetzungen
- Xcode 15 oder neuer empfohlen
- iOS / iPadOS 16.0 oder neuer
- echtes iPhone/iPad mit rückwärtiger Kamera

## Start
1. `GrowLightMeter.xcodeproj` in Xcode öffnen.
2. Unter **Signing & Capabilities** das eigene Apple Developer Team auswählen.
3. Falls nötig die Bundle-ID `de.growcentral.GrowLightMeter` auf eine eigene eindeutige ID ändern.
4. iPhone/iPad anschließen und als Target auswählen.
5. App starten und Kamerazugriff erlauben.

## Messprinzip
Die App liest ISO, Belichtungszeit und Blende der rückwärtigen Weitwinkelkamera aus und schätzt daraus die Beleuchtungsstärke. Über ein spektrales Preset wird Lux näherungsweise in PPFD umgerechnet. Das ist keine echte PAR-Spektralmessung.

## Empfohlene Nutzung
Für reproduzierbare Ergebnisse eine matte 18-%-Graukarte verwenden und mit einem Referenzmessgerät kalibrieren. Weißes Papier ist nur als Behelf vorgesehen.
