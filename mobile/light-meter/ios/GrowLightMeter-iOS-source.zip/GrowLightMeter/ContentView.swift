import SwiftUI

struct ContentView: View {
    @ObservedObject var meter: LightMeter

    @AppStorage("lightSource") private var storedLightSource = LightSource.whiteLED.rawValue
    @AppStorage("measureTarget") private var storedMeasureTarget = MeasureTarget.gray.rawValue
    @AppStorage("calibration") private var calibration = 1.0
    @AppStorage("dailyHours") private var hours = 18.0

    @State private var frozenLux: Double?

    private var source: Binding<LightSource> {
        Binding(
            get: { LightSource(rawValue: storedLightSource) ?? .whiteLED },
            set: { storedLightSource = $0.rawValue }
        )
    }

    private var target: Binding<MeasureTarget> {
        Binding(
            get: { MeasureTarget(rawValue: storedMeasureTarget) ?? .gray },
            set: { storedMeasureTarget = $0.rawValue }
        )
    }

    private var currentSource: LightSource { source.wrappedValue }
    private var currentTarget: MeasureTarget { target.wrappedValue }
    private var liveLux: Double { max(0, meter.rawLux * currentTarget.factor * calibration) }
    private var lux: Double { frozenLux ?? liveLux }
    private var ppfd: Double { max(0, lux * currentSource.ppfdPerLux) }
    private var dli: Double { ppfd * hours * 3600 / 1_000_000 }

    var body: some View {
        GeometryReader { proxy in
            ScrollView {
                if proxy.size.width >= 760 {
                    iPadLayout
                        .padding(24)
                } else {
                    iPhoneLayout
                        .padding(16)
                }
            }
            .background(Color(.systemGroupedBackground))
        }
        .navigationTitle("Grow Light Meter")
    }

    private var iPhoneLayout: some View {
        VStack(spacing: 16) {
            header
            previewCard
            resultCard
            settingsCard
            dliCard
            hintCard
        }
    }

    private var iPadLayout: some View {
        VStack(spacing: 20) {
            header
            HStack(alignment: .top, spacing: 20) {
                VStack(spacing: 20) {
                    previewCard
                    hintCard
                }
                .frame(maxWidth: .infinity)

                VStack(spacing: 20) {
                    resultCard
                    settingsCard
                    dliCard
                }
                .frame(maxWidth: .infinity)
            }
        }
        .frame(maxWidth: 1100)
        .frame(maxWidth: .infinity)
    }

    private var header: some View {
        HStack(alignment: .center, spacing: 12) {
            Image(systemName: "sun.max.fill")
                .font(.title2)
                .symbolRenderingMode(.hierarchical)
            VStack(alignment: .leading, spacing: 2) {
                Text("Grow Light Meter")
                    .font(.title2.bold())
                Text("Kamera-basierte PPFD- und DLI-Schätzung")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
            Spacer()
        }
        .accessibilityElement(children: .combine)
    }

    private var previewCard: some View {
        ZStack {
            CameraPreview(session: meter.session)

            Circle()
                .stroke(.white.opacity(0.9), lineWidth: 2)
                .frame(width: 42, height: 42)
                .shadow(radius: 2)

            VStack {
                Spacer()
                HStack(spacing: 6) {
                    Image(systemName: meter.quality.systemImage)
                    Text(meter.quality.rawValue)
                }
                .font(.caption.weight(.semibold))
                .padding(.horizontal, 10)
                .padding(.vertical, 7)
                .background(.ultraThinMaterial, in: Capsule())
                .padding(12)
            }
        }
        .frame(minHeight: 220, idealHeight: 280, maxHeight: 340)
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .strokeBorder(.white.opacity(0.08))
        }
        .overlay(alignment: .bottom) {
            if let message = meter.errorMessage {
                Text(message)
                    .font(.footnote)
                    .multilineTextAlignment(.center)
                    .padding(10)
                    .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 12))
                    .padding(12)
            }
        }
        .accessibilityLabel("Kameravorschau zur Lichtmessung")
    }

    private var resultCard: some View {
        VStack(spacing: 8) {
            Text("PPFD (geschätzt)")
                .font(.headline)
                .foregroundStyle(.secondary)

            ViewThatFits(in: .horizontal) {
                Text(ppfd.formatted(.number.precision(.fractionLength(0))))
                    .font(.system(size: 72, weight: .bold, design: .rounded))
                    .minimumScaleFactor(0.55)
                    .lineLimit(1)
                    .monospacedDigit()

                Text(ppfd.formatted(.number.precision(.fractionLength(0))))
                    .font(.system(size: 56, weight: .bold, design: .rounded))
                    .minimumScaleFactor(0.45)
                    .lineLimit(1)
                    .monospacedDigit()
            }

            Text("µmol/m²/s")
                .font(.headline)
                .foregroundStyle(.secondary)

            Text("\(lux.formatted(.number.precision(.fractionLength(0)))) lux · \(stage(ppfd))")
                .font(.callout)
                .multilineTextAlignment(.center)

            Button {
                withAnimation(.easeInOut(duration: 0.2)) {
                    frozenLux = frozenLux == nil ? liveLux : nil
                }
            } label: {
                Label(frozenLux == nil ? "Wert halten" : "Weiter messen",
                      systemImage: frozenLux == nil ? "pause.fill" : "play.fill")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
            .padding(.top, 8)
        }
        .card()
        .accessibilityElement(children: .contain)
    }

    private var settingsCard: some View {
        VStack(alignment: .leading, spacing: 16) {
            Label("Messung", systemImage: "slider.horizontal.3")
                .font(.headline)

            LabeledContent("Lichtquelle") {
                Picker("Lichtquelle", selection: source) {
                    ForEach(LightSource.allCases) { item in
                        Text(item.rawValue).tag(item)
                    }
                }
                .labelsHidden()
            }

            Text(currentSource.note)
                .font(.caption)
                .foregroundStyle(.secondary)

            Divider()

            LabeledContent("Messfläche") {
                Picker("Messfläche", selection: target) {
                    ForEach(MeasureTarget.allCases) { item in
                        Text(item.rawValue).tag(item)
                    }
                }
                .labelsHidden()
            }

            Text(currentTarget.note)
                .font(.caption)
                .foregroundStyle(.secondary)

            Divider()

            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text("Kalibrierfaktor")
                    Spacer()
                    Text(calibration.formatted(.number.precision(.fractionLength(2))))
                        .monospacedDigit()
                }
                Slider(value: $calibration, in: 0.20...5.0, step: 0.05)
                HStack {
                    Button("Zurücksetzen") { calibration = 1.0 }
                        .font(.caption)
                    Spacer()
                    Text("0,20 – 5,00")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
        }
        .card()
    }

    private var dliCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("Tageslichtintegral (DLI)", systemImage: "clock.fill")
                .font(.headline)

            HStack {
                Text("Lichtdauer")
                Spacer()
                Text("\(Int(hours)) h/Tag")
                    .monospacedDigit()
            }

            Slider(value: $hours, in: 1...24, step: 1)

            Text("\(dli.formatted(.number.precision(.fractionLength(1)))) mol/m²/Tag")
                .font(.title3.bold())
                .monospacedDigit()

            Text("DLI wird aus dem aktuellen PPFD-Wert und der eingestellten täglichen Lichtdauer berechnet.")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .card()
    }

    private var hintCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("Messhinweise", systemImage: "info.circle.fill")
                .font(.headline)

            Text("Für reproduzierbare Messungen eine matte 18-%-Graukarte auf Höhe der Messfläche verwenden. Das iPhone so ausrichten, dass die Karte mittig im Fadenkreuz liegt und weder Hand noch Gerät einen Schatten auf die Messfläche werfen.")

            Text("Diese App verwendet Kamerabelichtungsdaten und keine echte Spektralmessung. Für eine präzise PPFD-Messung ist ein kalibriertes Quantum-Meter erforderlich.")
                .foregroundStyle(.secondary)
        }
        .font(.footnote)
        .card()
    }

    private func stage(_ ppfd: Double) -> String {
        switch ppfd {
        case ..<100: return "sehr schwach"
        case ..<300: return "niedrig"
        case ..<600: return "mittel"
        case ..<1000: return "hoch"
        default: return "sehr hoch"
        }
    }
}

private extension View {
    func card() -> some View {
        padding(18)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color(.secondarySystemGroupedBackground))
            .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
    }
}

#Preview {
    NavigationStack {
        ContentView(meter: LightMeter())
    }
}
