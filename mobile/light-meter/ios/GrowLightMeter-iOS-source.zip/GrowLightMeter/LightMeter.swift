import AVFoundation
import Combine
import UIKit

final class LightMeter: ObservableObject {
    let session = AVCaptureSession()

    @Published private(set) var rawLux: Double = 0
    @Published private(set) var quality: MeasurementQuality = .waiting
    @Published private(set) var isRunning = false
    @Published var errorMessage: String?

    private let sessionQueue = DispatchQueue(label: "de.growlightmeter.camera.session", qos: .userInitiated)
    private let sampleQueue = DispatchQueue(label: "de.growlightmeter.camera.samples", qos: .userInteractive)

    private var configured = false
    private var device: AVCaptureDevice?
    private var timer: DispatchSourceTimer?
    private var samples: [Double] = []
    private let maxSamples = 12

    func start() {
        DispatchQueue.main.async {
            UIApplication.shared.isIdleTimerDisabled = true
        }

        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            configureAndRun()
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
                guard let self else { return }
                if granted {
                    self.configureAndRun()
                } else {
                    self.publishError("Kamerazugriff verweigert. Bitte in Einstellungen > Datenschutz & Sicherheit > Kamera erlauben.")
                }
            }
        case .denied, .restricted:
            publishError("Kamerazugriff ist nicht verfügbar. Bitte die Berechtigung in den iOS-Einstellungen prüfen.")
        @unknown default:
            publishError("Der Kamerastatus konnte nicht ermittelt werden.")
        }
    }

    func stop() {
        DispatchQueue.main.async {
            UIApplication.shared.isIdleTimerDisabled = false
        }

        stopSampling()
        sessionQueue.async { [weak self] in
            guard let self else { return }
            if self.session.isRunning {
                self.session.stopRunning()
            }
            DispatchQueue.main.async {
                self.isRunning = false
                self.quality = .waiting
            }
        }
    }

    private func configureAndRun() {
        sessionQueue.async { [weak self] in
            guard let self else { return }

            if !self.configured {
                guard self.configureSession() else { return }
            }

            guard !self.session.isRunning else {
                self.startSampling()
                return
            }

            self.session.startRunning()
            DispatchQueue.main.async {
                self.errorMessage = nil
                self.isRunning = true
            }
            self.startSampling()
        }
    }

    @discardableResult
    private func configureSession() -> Bool {
        session.beginConfiguration()
        defer { session.commitConfiguration() }

        // .inputPriority avoids unnecessary video processing; only exposure metadata is needed.
        session.sessionPreset = .inputPriority

        let discovery = AVCaptureDevice.DiscoverySession(
            deviceTypes: [.builtInWideAngleCamera],
            mediaType: .video,
            position: .back
        )

        guard let camera = discovery.devices.first else {
            publishError("Keine geeignete rückwärtige Kamera gefunden.")
            return false
        }

        do {
            let input = try AVCaptureDeviceInput(device: camera)
            guard session.canAddInput(input) else {
                publishError("Die Kamera konnte nicht zur Messsitzung hinzugefügt werden.")
                return false
            }
            session.addInput(input)
        } catch {
            publishError("Kamera konnte nicht geöffnet werden: \(error.localizedDescription)")
            return false
        }

        do {
            try camera.lockForConfiguration()
            defer { camera.unlockForConfiguration() }

            if camera.isFocusModeSupported(.continuousAutoFocus) {
                camera.focusMode = .continuousAutoFocus
            }
            if camera.isExposureModeSupported(.continuousAutoExposure) {
                camera.exposureMode = .continuousAutoExposure
            }

            let neutralBias = min(max(0.0, camera.minExposureTargetBias), camera.maxExposureTargetBias)
            camera.setExposureTargetBias(neutralBias, completionHandler: nil)
        } catch {
            // Measuring can still work with the device's current configuration.
        }

        device = camera
        configured = true
        return true
    }

    private func startSampling() {
        sampleQueue.async { [weak self] in
            guard let self else { return }
            guard self.timer == nil else { return }

            self.samples.removeAll(keepingCapacity: true)
            let source = DispatchSource.makeTimerSource(queue: self.sampleQueue)
            source.schedule(deadline: .now() + 0.3, repeating: .milliseconds(200), leeway: .milliseconds(25))
            source.setEventHandler { [weak self] in
                self?.sampleExposure()
            }
            self.timer = source
            source.resume()
        }
    }

    private func stopSampling() {
        sampleQueue.async { [weak self] in
            guard let self else { return }
            self.timer?.setEventHandler {}
            self.timer?.cancel()
            self.timer = nil
            self.samples.removeAll(keepingCapacity: false)
        }
    }

    private func sampleExposure() {
        guard let camera = device else { return }

        let iso = Double(camera.iso)
        let exposureSeconds = CMTimeGetSeconds(camera.exposureDuration)
        let aperture = Double(camera.lensAperture)

        guard iso.isFinite, exposureSeconds.isFinite, aperture.isFinite,
              iso > 0, exposureSeconds > 0, aperture > 0 else { return }

        // Reflected-light estimate calibrated around an 18% grey target.
        // E ~= C * N^2 / (t * ISO), C is an empirical calibration constant.
        let luxEstimate = 250.0 * aperture * aperture / (exposureSeconds * iso)
        guard luxEstimate.isFinite, luxEstimate >= 0 else { return }

        samples.append(luxEstimate)
        if samples.count > maxSamples {
            samples.removeFirst(samples.count - maxSamples)
        }

        let filtered = robustAverage(samples)
        let state = measurementQuality(camera: camera, lux: filtered)

        DispatchQueue.main.async { [weak self] in
            self?.rawLux = filtered
            self?.quality = state
        }
    }

    /// Drops the outer quartiles before averaging. This reacts quickly while suppressing exposure spikes.
    private func robustAverage(_ values: [Double]) -> Double {
        guard !values.isEmpty else { return 0 }
        guard values.count >= 5 else {
            return values.reduce(0, +) / Double(values.count)
        }

        let sorted = values.sorted()
        let trim = max(1, sorted.count / 4)
        let middle = sorted.dropFirst(trim).dropLast(trim)
        return middle.reduce(0, +) / Double(middle.count)
    }

    private func measurementQuality(camera: AVCaptureDevice, lux: Double) -> MeasurementQuality {
        if camera.isAdjustingExposure { return .adjusting }
        if lux < 5 { return .tooDark }

        let nearMinimumExposure = camera.exposureDuration.seconds <= camera.activeFormat.minExposureDuration.seconds * 1.10
        let nearMinimumISO = camera.iso <= camera.activeFormat.minISO * 1.10
        if nearMinimumExposure && nearMinimumISO {
            return .possibleClipping
        }
        return .stable
    }

    private func publishError(_ message: String) {
        DispatchQueue.main.async { [weak self] in
            self?.errorMessage = message
            self?.quality = .waiting
            self?.isRunning = false
        }
    }
}
