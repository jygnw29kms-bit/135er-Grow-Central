import Foundation

/// Spectral presets used for a rough lux -> PPFD conversion.
/// A calibrated quantum sensor remains the reference for accurate PPFD values.
enum LightSource: String, CaseIterable, Identifiable, Codable {
    case sun = "Sonnenlicht"
    case whiteLED = "Weiße LED (Vollspektrum)"
    case warmLED = "Warmweiße LED"
    case hps = "Natriumdampf (HPS)"
    case blurple = "Rot/Blau-LED (Blurple)"

    var id: String { rawValue }

    var ppfdPerLux: Double {
        switch self {
        case .sun:      return 0.0185
        case .whiteLED: return 0.0150
        case .warmLED:  return 0.0140
        case .hps:      return 0.0122
        case .blurple:  return 0.0080
        }
    }

    var note: String {
        switch self {
        case .blurple:
            return "Bei Rot/Blau-LEDs ist die Lux-Umrechnung besonders ungenau."
        default:
            return "Die Umrechnung ist eine Näherung und hängt vom Spektrum der Lampe ab."
        }
    }
}

enum MeasureTarget: String, CaseIterable, Identifiable, Codable {
    case gray = "Graukarte (18 %)"
    case paper = "Weißes Papier"

    var id: String { rawValue }

    /// Reflection correction. A proper 18% grey card is the preferred target.
    var factor: Double {
        switch self {
        case .gray: return 1.0
        case .paper: return 0.20
        }
    }

    var note: String {
        switch self {
        case .gray:
            return "Empfohlen. Eine matte 18-%-Graukarte liefert reproduzierbarere Werte."
        case .paper:
            return "Nur als Behelf. Papierweiß, Glanz und Aufheller können den Messwert deutlich verändern."
        }
    }
}

enum MeasurementQuality: String {
    case waiting = "Warte auf Kamera"
    case adjusting = "Belichtung stabilisiert sich"
    case stable = "Messung stabil"
    case tooDark = "Zu dunkel"
    case possibleClipping = "Sehr hell – Sättigung möglich"

    var systemImage: String {
        switch self {
        case .waiting: return "hourglass"
        case .adjusting: return "circle.dotted"
        case .stable: return "checkmark.circle.fill"
        case .tooDark: return "moon.fill"
        case .possibleClipping: return "sun.max.trianglebadge.exclamationmark.fill"
        }
    }
}
