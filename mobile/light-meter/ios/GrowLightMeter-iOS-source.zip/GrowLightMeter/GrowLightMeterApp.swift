import SwiftUI

@main
struct GrowLightMeterApp: App {
    @Environment(\.scenePhase) private var scenePhase
    @StateObject private var meter = LightMeter()

    var body: some Scene {
        WindowGroup {
            ContentView(meter: meter)
                .onChange(of: scenePhase) { newPhase in
                    switch newPhase {
                    case .active:
                        meter.start()
                    case .inactive, .background:
                        meter.stop()
                    @unknown default:
                        break
                    }
                }
        }
    }
}
